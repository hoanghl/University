#ifndef _9DOF_HPP_
#define _9DOF_HPP_

#define     DELTA   5       // the interval used in main algorithm

void    init_9DOF();

/*
 * Capture the accelerometer values
 */
void    capture();


/*
 * Calculate 
 */
float   calculate();





#endif