#ifndef LCDBUTTON_HPP_
#define LCDBUTTON_HPP_

void    init_LCDButton();
bool    isButAPressed();
void    printLCD_1();           // print as St_STOP
void    printLCD_2();           // print as St_RUN
void    printLCD_3();           // print as St_CALCULATE


#endif