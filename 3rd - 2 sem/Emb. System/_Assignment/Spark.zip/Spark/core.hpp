#ifndef CORE_HPP_
#define CORE_HPP_

enum State {St_STOP, St_RUN, St_CALCULATE, St_EXIT};

void    init();
void    run();

#endif