Feb 28
In Problem 2, take a view as makefile first before running