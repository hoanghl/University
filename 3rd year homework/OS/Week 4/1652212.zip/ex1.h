#ifndef EX1_H_
#define EX1_H_

void * aligned_malloc(unsigned int size, unsigned int align);
void * aligned_free(void *ptr);

#endif