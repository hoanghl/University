#ifndef STR_H_
#define STR_H_

struct Node {
    int _data;
    struct Node * _next;
};
#endif