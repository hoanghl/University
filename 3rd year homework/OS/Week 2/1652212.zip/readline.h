#ifndef READ_LINE_H
#define READ_LINE_H

#define MAX_BUFF    4096

int read_line(char *str);

#endif