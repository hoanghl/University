#ifndef FIND_SUBSTR_H
#define FIND_SUBSTR_H

int find_sub_string(const char * str, const char * sub);

#endif
