#include    "findsubstr.h"
#include    <stdio.h>

int main(){
    printf("return: %d\n", find_sub_string("ABCDEFFGHIKLMN", "dFF"));
    return 0;
}


